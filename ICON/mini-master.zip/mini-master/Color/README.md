
![示例](https://raw.githubusercontent.com/Orz-3/mini/none/头部.png)

## mini项目

**注意：** 本库中图标为彩色版本，透明版本在mini库中

##### Telegram频道： [mini计划-图标聚合](https://t.me/Orzmini)

### 使用方法：

####  1、文本编辑中使用
打开QuanX 配置文件-编辑，找到［task_local］字段，在想要增加图标的相应签到脚本段落中修改，在enable＝true之前加上 `img-url=https://raw.githubusercontent.com/Orz-3/task/master/name.png` 注意此句和前后句都要用英文逗号隔开，并且逗号后先要空一格

####  2、UI中使用
主界面右下角点击风车开启菜单，然后找到调试一栏下的构造请求，点击进入构造请求界面，左滑相应task，点击编辑，在图标一栏填写 `https://raw.githubusercontent.com/Orz-3/task/master/name.png`

🔘彩色版本 `https://raw.githubusercontent.com/Orz-3/task/master/name.png`

🔘透明版本 `https://raw.githubusercontent.com/Orz-3/mini/master/name.png`

  **注：** task图标的透明和彩色版本文件名完全一致，仅所在库不同

##### 图标索引，最上方为图标展示，下面第一行为对应机场的名称，第二行为文件名，请将使用方法中的name.png替换成相应文件的文件名

![示例](https://raw.githubusercontent.com/Orz-3/mini/none/c1.png)

![示例](https://raw.githubusercontent.com/Orz-3/mini/none/c2.png)

![示例](https://raw.githubusercontent.com/Orz-3/mini/none/c3.png)

![示例](https://raw.githubusercontent.com/Orz-3/mini/none/c4.png)

![示例](https://raw.githubusercontent.com/Orz-3/mini/none/c5.png)

![示例](https://raw.githubusercontent.com/Orz-3/mini/none/c6.png)

![示例](https://raw.githubusercontent.com/Orz-3/mini/none/c7.png)

![示例](https://raw.githubusercontent.com/Orz-3/mini/none/yaofan.png)


